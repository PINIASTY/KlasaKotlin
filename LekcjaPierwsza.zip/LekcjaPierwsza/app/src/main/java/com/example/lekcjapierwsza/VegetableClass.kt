package com.example.lekcjapierwsza

data class Vegetable(val name: String, val age: Int, val originCountry: String)

val vegetableList = listOf(Vegetable("Tomato",10,"Spain"),
    Vegetable("Cabbage",3,"Japan"),
    Vegetable("Cucumber",11,"Great Britain"))

fun main(){
    var oldestVegetable: Vegetable? = null
    for(vegetable in vegetableList){
        println(vegetable.name)
        if(oldestVegetable == null) oldestVegetable = vegetable
        else if (vegetable.age > oldestVegetable.age) oldestVegetable = vegetable
        println("${vegetable.name} pochodzi z ${vegetable.originCountry} i ma ${vegetable.age} lat")
    }
    println("Najstarsze warzywo: $oldestVegetable")
}